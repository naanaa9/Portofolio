import { ImageWithFallback } from "./figma/ImageWithFallback";

export function About() {
  return (
    <section id="about" className="py-20 px-4 bg-white">
      <div className="max-w-6xl mx-auto">
        <h2 className="text-center mb-12 text-slate-900">About Me</h2>
        
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div>
            <ImageWithFallback
              src="https://images.unsplash.com/photo-1666723043169-22e29545675c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjB3b3Jrc3BhY2UlMjBkZXNrfGVufDF8fHx8MTc2NDE2OTk1N3ww&ixlib=rb-4.1.0&q=80&w=1080"
              alt="Workspace"
              className="rounded-lg shadow-2xl w-full h-auto"
            />
          </div>
          
          <div>
            <h3 className="mb-6 text-slate-900">Crafting Digital Experiences</h3>
            <p className="text-slate-600 mb-4">
              With over 5 years of experience in web development and design, I specialize in creating 
              elegant solutions to complex problems. My approach combines technical expertise with 
              creative thinking to deliver exceptional results.
            </p>
            <p className="text-slate-600 mb-4">
              I've worked with startups and established companies, helping them build and scale their 
              digital presence. From responsive websites to complex web applications, I bring ideas to life 
              with clean, efficient code.
            </p>
            <p className="text-slate-600 mb-6">
              When I'm not coding, you can find me exploring new technologies, contributing to open-source 
              projects, or sharing knowledge with the developer community.
            </p>
            
            <div className="flex gap-4 flex-wrap">
              <div className="px-4 py-2 bg-slate-100 rounded-lg text-slate-700">
                5+ Years Experience
              </div>
              <div className="px-4 py-2 bg-slate-100 rounded-lg text-slate-700">
                50+ Projects Completed
              </div>
              <div className="px-4 py-2 bg-slate-100 rounded-lg text-slate-700">
                30+ Happy Clients
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
