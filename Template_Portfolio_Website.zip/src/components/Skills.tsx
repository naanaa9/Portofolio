import { Code2, Palette, Smartphone, Database, Globe, Zap } from "lucide-react";

const skills = [
  {
    icon: Code2,
    title: "Frontend Development",
    description: "React, TypeScript, Next.js, Tailwind CSS",
    color: "bg-blue-500"
  },
  {
    icon: Database,
    title: "Backend Development",
    description: "Node.js, Python, PostgreSQL, MongoDB",
    color: "bg-green-500"
  },
  {
    icon: Palette,
    title: "UI/UX Design",
    description: "Figma, Adobe XD, User Research",
    color: "bg-purple-500"
  },
  {
    icon: Smartphone,
    title: "Responsive Design",
    description: "Mobile-first, Cross-browser compatibility",
    color: "bg-pink-500"
  },
  {
    icon: Globe,
    title: "Web Performance",
    description: "SEO, Core Web Vitals, Optimization",
    color: "bg-orange-500"
  },
  {
    icon: Zap,
    title: "Modern Workflows",
    description: "Git, CI/CD, Agile, Testing",
    color: "bg-yellow-500"
  }
];

export function Skills() {
  return (
    <section className="py-20 px-4 bg-slate-50">
      <div className="max-w-6xl mx-auto">
        <h2 className="text-center mb-4 text-slate-900">Skills & Expertise</h2>
        <p className="text-center text-slate-600 mb-12 max-w-2xl mx-auto">
          A comprehensive set of skills that enable me to bring your vision to life
        </p>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {skills.map((skill) => (
            <div
              key={skill.title}
              className="bg-white p-6 rounded-lg shadow-lg hover:shadow-xl transition-shadow"
            >
              <div className={`${skill.color} w-12 h-12 rounded-lg flex items-center justify-center mb-4`}>
                <skill.icon className="w-6 h-6 text-white" />
              </div>
              <h3 className="mb-2 text-slate-900">{skill.title}</h3>
              <p className="text-slate-600">{skill.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
